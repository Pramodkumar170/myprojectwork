package package1;

public class ProtectedModifier {
	protected void msg() {
		System.out.println("Hello World");
	}
}
