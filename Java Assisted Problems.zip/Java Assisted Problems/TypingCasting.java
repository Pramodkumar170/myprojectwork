
public class TypingCasting {
	public static void main(String args[]) {
		int x = 10;
		long y = x;
		System.out.println("Before conversion, int value"+x);
		System.out.println("After conversion, long value"+y);
		double d = 166.66;   
		long l = (long)d;  
		int i = (int)l;  
		System.out.println("Before conversion: "+d);  
		System.out.println("After conversion into long type: "+l); 
	}

}
