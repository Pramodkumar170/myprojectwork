interface Shape {
	int getArea(int a);
}

class Square implements Shape {

	@Override
	public int getArea(int a) {
		return a*a;
	}
	
}

class Circle implements Shape {

	@Override
	public int getArea(int a) {
		return (int) 3.14*a*a;
	}
}

class Rectangle {
	public int getArea(int a, int b) {
		return a*b;
	}
}


public class AreaCalculator {
	public static void main(String[] args) {
		Square s = new Square();
		System.out.println("Area of square: "+s.getArea(3));
		
		Circle c = new Circle();
		System.out.println("Area of circle: "+c.getArea(3));
		
		Rectangle r = new Rectangle();
		System.out.println("Area of rectangle: "+r.getArea(3,4));
	}
}
