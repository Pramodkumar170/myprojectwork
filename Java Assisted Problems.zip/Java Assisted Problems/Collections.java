import java.util.*;

public class Collections {
	public static void main(String[] args)
    {
        // Creating a Map
        Map<Integer, String> map = new HashMap<>();
 
        // Adding elements to map
        map.put(1, "Geeks");
        map.put(2, "are");
        map.put(3, "you");
        map.put(4, "working");
 
        // Traversing Map
        // Converting to Set so that traversal is accessed
        Set<?> set = map.entrySet();
 
        // Iterator
        Iterator itr = set.iterator();
 
        // Condition check over elements inside using
        // hasNext() method which holds true till there is
        // element inside list
 
        while (itr.hasNext()) {
            // Converting to Map.Entry so that we can get
            // key and value separately
 
            Map.Entry entry = (Map.Entry)itr.next();
 
            // Printing elements inside HashMap
            System.out.println(entry.getKey() + " "
                               + entry.getValue());
        }
    }

}
