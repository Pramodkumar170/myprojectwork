import package1.*;

public class AccessModifier{
	public static void main(String args[]) {
		
		PrivateModifier privateObj = new PrivateModifier();
		System.out.println(privateObj.data);
		privateObj.msg();
		
		ProtectedModifier protectedObj = new ProtectedModifier();	
		protectedObj.msg();
	}
}
class PrivateModifier{
	private int data = 100;
	private void msg() {
		System.out.println("Hello");
	}
}
